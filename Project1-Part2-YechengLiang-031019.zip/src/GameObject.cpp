#include "GameObject.h"

GameObject::GameObject() {
}

void GameObject::draw() {
}

//void GameObject::collision(glm::vec3) {
//}

void GameObject::update() {
}


