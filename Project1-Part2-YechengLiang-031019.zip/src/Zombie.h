#pragma once
#include "Pawn.h"

class Zombie : public Pawn {

};