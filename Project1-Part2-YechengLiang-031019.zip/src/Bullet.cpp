#include "Bullet.h"
#include "ofApp.h"

void Bullet::update() {
	//Particle::update();
	cout << "Bullet Update" << endl;

}